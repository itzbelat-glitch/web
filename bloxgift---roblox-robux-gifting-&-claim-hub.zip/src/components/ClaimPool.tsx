import React, { useState, useEffect } from 'react';
import {
  Coins,
  Loader2,
  Check,
  ShieldCheck,
  CheckCircle2,
  Search,
  ExternalLink,
  Sparkles,
  User,
  TrendingUp,
  Calendar,
  Users,
  UserCheck,
  ArrowUpRight,
} from 'lucide-react';
import { RobloxUser } from '../types';
import {
  lookupRobloxProfile,
  DEFAULT_AVATAR,
  DEV_CONTROLX_USER,
  QUEENCHESCAX_USER,
  NOOCHI1279_USER,
} from '../utils/roblox';
import { playSuccessSound } from '../utils/audio';
import { AccountConfirmModal } from './AccountConfirmModal';

interface ClaimPoolProps {
  poolRemaining: number;
  poolTotal: number;
  initialUsername?: string;
  onClaimSuccess: (user: RobloxUser, amount: number) => void;
  onNotify: (title: string, message?: string, type?: 'success' | 'info' | 'error') => void;
}

export const ClaimPool: React.FC<ClaimPoolProps> = ({
  poolRemaining,
  poolTotal,
  initialUsername = '',
  onClaimSuccess,
  onNotify,
}) => {
  // Empty Roblox username input by default
  const [claimUsername, setClaimUsername] = useState(initialUsername || '');
  const [selectedAmount, setSelectedAmount] = useState<number>(1000);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isClaiming, setIsClaiming] = useState(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);

  // Active verified player profile state (null when input is empty)
  const [verifiedUser, setVerifiedUser] = useState<RobloxUser | null>(
    initialUsername ? DEV_CONTROLX_USER : null
  );

  // Sync if prop changes
  useEffect(() => {
    if (initialUsername && initialUsername !== claimUsername) {
      setClaimUsername(initialUsername);
      verifyUser(initialUsername);
    }
  }, [initialUsername]);

  const verifyUser = async (targetName: string) => {
    const clean = targetName.trim();
    if (!clean) {
      setVerifiedUser(null);
      return;
    }

    setIsVerifying(true);
    try {
      const profile = await lookupRobloxProfile(clean);
      setVerifiedUser(profile);
      onNotify('Player Verified', `@${profile.username} profile & avatar connected`, 'success');
    } catch {
      onNotify('Lookup Notice', 'Loaded profile identifier for player', 'info');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleUsernameBlur = () => {
    const clean = claimUsername.trim();
    if (clean && (!verifiedUser || clean.toLowerCase() !== verifiedUser.username.toLowerCase())) {
      verifyUser(clean);
    }
  };

  // Triggered when form is submitted - verifies user if needed and opens confirmation modal
  const handleInitiateClaim = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = claimUsername.trim();
    if (!cleanUser) {
      onNotify('Username Missing', 'Please enter your Roblox username first', 'error');
      return;
    }

    if (poolRemaining < selectedAmount) {
      onNotify('Pool Exhausted', 'Daily reward pool depleted for this cycle. Wait for reset.', 'error');
      return;
    }

    // If no user verified or username changed, verify first before opening modal
    if (!verifiedUser || verifiedUser.username.toLowerCase() !== cleanUser.toLowerCase()) {
      setIsVerifying(true);
      try {
        const profile = await lookupRobloxProfile(cleanUser);
        setVerifiedUser(profile);
        setIsConfirmModalOpen(true);
      } catch {
        onNotify('Lookup Notice', `Verifying @${cleanUser}...`, 'info');
        setIsConfirmModalOpen(true);
      } finally {
        setIsVerifying(false);
      }
      return;
    }

    // Open Account Confirmation Modal
    setIsConfirmModalOpen(true);
  };

  // Called when user confirms "Yes, this is my account" in the confirmation modal
  const handleConfirmClaim = () => {
    const cleanUser = claimUsername.trim() || 'RobloxPlayer';
    const activePlayer: RobloxUser = verifiedUser || {
      username: cleanUser,
      displayName: cleanUser,
      id: Math.floor(100000000 + Math.random() * 900000000),
      avatar: DEFAULT_AVATAR,
      avatarHeadshot: DEFAULT_AVATAR,
      joinDate: 'Oct 2021',
      friendsCount: 140,
      followingCount: 65,
    };

    setIsClaiming(true);

    setTimeout(() => {
      setIsClaiming(false);
      onClaimSuccess(activePlayer, selectedAmount);
      playSuccessSound();
      onNotify(
        'Robux Claim Transferred!',
        `Successfully transferred ${selectedAmount.toLocaleString()} R$ to @${activePlayer.username}`,
        'success'
      );
    }, 20000);
  };

  const percentage = Math.max(0, Math.min(100, Math.round((poolRemaining / poolTotal) * 100)));

  return (
    <section id="daily-pool-section" className="bg-[#14161c] border border-[#242832] rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
      {/* Background ambient glow */}
      <div className="absolute -top-16 -right-16 w-80 h-80 bg-[#00e676]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-16 -left-16 w-80 h-80 bg-[#00a2ff]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Pool Header & Status Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-[#242832] relative z-10">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 bg-[#00e676]/10 border border-[#00e676]/25 text-[#00e676] rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-[#00e676]/10">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Daily Robux Claim Pool
              </h2>
              <span className="text-xs font-mono font-bold text-[#ffb800] bg-[#ffb800]/10 border border-[#ffb800]/25 px-2.5 py-0.5 rounded-full">
                DISTRIBUTION ACTIVE
              </span>
            </div>
            <p className="text-xs sm:text-sm text-gray-400 mt-0.5">
              Live avatar verification · Realtime account confirmation · Instant community distribution
            </p>
          </div>
        </div>

        {/* Pool Remaining Metric */}
        <div className="bg-[#0e1015] border border-[#242832] px-4 py-2.5 rounded-2xl flex items-center gap-4 self-start md:self-auto">
          <div>
            <div className="text-[11px] text-gray-400 font-medium">Pool Balance Remaining</div>
            <div className="text-sm sm:text-base font-extrabold text-[#00e676] font-mono tabular-nums">
              {poolRemaining.toLocaleString()} / {poolTotal.toLocaleString()} R$
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-xs font-black font-mono text-emerald-400">
            {percentage}%
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="my-6 space-y-2 relative z-10">
        <div className="w-full h-3 bg-[#0d0f14] rounded-full overflow-hidden border border-[#242832] p-0.5">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 via-[#00e676] to-cyan-400 rounded-full transition-all duration-500"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>

      {/* Main Grid: Live Roblox Player Profile (Headshot + Account Metrics) + Claim Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch relative z-10 mt-6">
        
        {/* Left (5 cols): Real-Time Player Profile Card with Headshot, Join Date, Friends, Following */}
        <div className="lg:col-span-5 bg-[#0d0f14] border border-[#242832] rounded-2xl p-5 flex flex-col justify-between">
          <div>
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-[#00a2ff]" />
                <span>Player Profile</span>
              </span>

              {isVerifying ? (
                <span className="text-xs font-mono text-[#00a2ff] flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" /> Verifying...
                </span>
              ) : verifiedUser ? (
                <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> API Verified
                </span>
              ) : (
                <span className="text-[11px] text-gray-400 font-mono flex items-center gap-1">
                  Awaiting Username
                </span>
              )}
            </div>

            {/* Avatar Headshot & Player Details */}
            {verifiedUser ? (
              <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
                <div className="relative shrink-0">
                  <div className="w-24 h-24 rounded-2xl bg-gradient-to-b from-[#181d29] to-[#0f1218] border-2 border-[#00a2ff]/40 overflow-hidden shadow-xl flex items-center justify-center">
                    <img
                      src={verifiedUser.avatarHeadshot || verifiedUser.avatar}
                      alt={verifiedUser.displayName}
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                      }}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div
                    className="absolute -bottom-1 -right-1 bg-[#00a2ff] text-white rounded-full p-1 shadow-md"
                    title="Verified Account"
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                </div>

                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center justify-center sm:justify-start gap-1.5 flex-wrap">
                    <span className="text-lg font-black text-white truncate">
                      {verifiedUser.displayName}
                    </span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  </div>
                  
                  <div className="text-xs font-semibold text-[#00a2ff] truncate">
                    @{verifiedUser.username}
                  </div>
                  
                  <div className="text-[11px] text-gray-400 font-mono tabular-nums">
                    Roblox ID: <span className="text-gray-300 font-bold">{verifiedUser.id}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
                <div className="w-24 h-24 rounded-2xl bg-[#12151e] border-2 border-dashed border-[#2d3444] flex items-center justify-center shrink-0">
                  <User className="w-10 h-10 text-gray-500" />
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="text-base font-bold text-gray-300">
                    No Player Selected
                  </div>
                  <div className="text-xs text-gray-400 leading-relaxed">
                    Enter your Roblox username or pick a player below to inspect headshot and account stats.
                  </div>
                </div>
              </div>
            )}

            {/* Account Verification Details Strip: Join Date, Friends, Following */}
            <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-[#1e222c]">
              <div className="bg-[#131620] border border-[#232938] rounded-xl p-2 text-center">
                <div className="flex items-center justify-center gap-1 text-[10px] text-gray-400 font-semibold mb-0.5">
                  <Calendar className="w-2.5 h-2.5 text-cyan-400" />
                  <span>Joined</span>
                </div>
                <div className="text-[11px] font-bold text-white truncate font-mono">
                  {verifiedUser?.joinDate || '--'}
                </div>
              </div>

              <div className="bg-[#131620] border border-[#232938] rounded-xl p-2 text-center">
                <div className="flex items-center justify-center gap-1 text-[10px] text-gray-400 font-semibold mb-0.5">
                  <Users className="w-2.5 h-2.5 text-[#00e676]" />
                  <span>Friends</span>
                </div>
                <div className="text-[11px] font-extrabold text-white font-mono tabular-nums">
                  {verifiedUser?.friendsCount !== undefined ? verifiedUser.friendsCount.toLocaleString() : '--'}
                </div>
              </div>

              <div className="bg-[#131620] border border-[#232938] rounded-xl p-2 text-center">
                <div className="flex items-center justify-center gap-1 text-[10px] text-gray-400 font-semibold mb-0.5">
                  <UserCheck className="w-2.5 h-2.5 text-amber-400" />
                  <span>Following</span>
                </div>
                <div className="text-[11px] font-extrabold text-white font-mono tabular-nums">
                  {verifiedUser?.followingCount !== undefined ? verifiedUser.followingCount.toLocaleString() : '--'}
                </div>
              </div>
            </div>

            {/* Rolimon's Player Metrics (RAP & Value) */}
            <div className="mt-3 bg-[#131620] border border-[#232938] rounded-xl p-2.5 text-left space-y-1">
              <div className="flex items-center justify-between text-[10px] text-gray-400 uppercase tracking-wider font-semibold">
                <span className="flex items-center gap-1 text-cyan-400">
                  <TrendingUp className="w-3 h-3" /> Rolimon's Trading Profile
                </span>
                {verifiedUser?.rolimonsRank && (
                  <span className="text-amber-400 font-mono">#{verifiedUser.rolimonsRank}</span>
                )}
              </div>
              <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                <span className="text-gray-400">RAP:</span>
                <span className="font-bold text-white">
                  {verifiedUser?.rolimonsRap ? `${verifiedUser.rolimonsRap.toLocaleString()} R$` : '--'}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                <span className="text-gray-400">Value:</span>
                <span className="font-bold text-[#00e676]">
                  {verifiedUser?.rolimonsValue ? `${verifiedUser.rolimonsValue.toLocaleString()} R$` : '--'}
                </span>
              </div>
            </div>

            {/* External Links */}
            {verifiedUser && (
              <div className="mt-3 flex flex-wrap gap-2 justify-center sm:justify-start">
                <a
                  href={verifiedUser.rolimonsUrl || `https://www.rolimons.com/player/${verifiedUser.id}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-[11px] bg-cyan-950/50 hover:bg-cyan-900/60 text-cyan-300 border border-cyan-500/40 px-2.5 py-1 rounded-lg transition-colors inline-flex items-center gap-1 font-semibold"
                  title="View trading history and inventory on Rolimon's"
                >
                  <span>Rolimon's Player</span>
                  <ArrowUpRight className="w-3 h-3" />
                </a>

                <a
                  href={`https://www.roblox.com/users/${verifiedUser.id}/profile`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-[11px] text-gray-400 hover:text-white px-2 py-1 transition-colors inline-flex items-center gap-1"
                >
                  <span>Roblox Profile</span>
                  <ExternalLink className="w-2.5 h-2.5" />
                </a>
              </div>
            )}
          </div>

          {/* Quick Select Players: dev_controlx, queenchescax, noochi1279 */}
          <div className="mt-5 pt-4 border-t border-[#242832]/70">
            <div className="text-[11px] font-semibold text-gray-400 mb-2 flex items-center justify-between">
              <span>Quick Player Select:</span>
              <span className="text-[10px] text-cyan-400 font-mono font-semibold">Top Claimers</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {[
                { user: DEV_CONTROLX_USER, rankLabel: 'Rank #1', badge: '🥇' },
                { user: QUEENCHESCAX_USER, rankLabel: 'Rank #2', badge: '🥈' },
                { user: NOOCHI1279_USER, rankLabel: 'Rank #3', badge: '🥉' },
              ].map(({ user, rankLabel, badge }) => {
                const isSelected = verifiedUser?.username.toLowerCase() === user.username.toLowerCase();
                return (
                  <button
                    key={user.username}
                    type="button"
                    onClick={() => {
                      setClaimUsername(user.username);
                      setVerifiedUser(user);
                      onNotify('Player Selected', `@${user.username} verified for claim`, 'success');
                    }}
                    className={`bg-[#161a25] hover:bg-[#1f2434] border ${
                      isSelected ? 'border-[#00a2ff] ring-1 ring-[#00a2ff]/60 bg-[#162132]' : 'border-[#293040] hover:border-cyan-500/50'
                    } p-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer text-left group shadow-sm`}
                  >
                    <img
                      src={user.avatarHeadshot || user.avatar}
                      alt={user.username}
                      className="w-8 h-8 rounded-lg border border-cyan-400/40 object-cover bg-[#0d0f14] shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-[11px] font-bold text-white group-hover:text-cyan-300 truncate flex items-center gap-1">
                        <span>{badge}</span>
                        <span className="truncate">@{user.username}</span>
                      </div>
                      <div className="text-[9px] text-gray-400 font-mono">
                        {rankLabel}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right (7 cols): Claim Form with Amount Selectors & Instant Verification Input */}
        <div className="lg:col-span-7 flex flex-col justify-between">
          <form onSubmit={handleInitiateClaim} className="space-y-4">
            
            {/* Username Input with Verify Trigger */}
            <div>
              <label className="block text-xs font-semibold text-gray-300 uppercase tracking-wider mb-2">
                Roblox Username
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={claimUsername}
                    onChange={(e) => setClaimUsername(e.target.value)}
                    onBlur={handleUsernameBlur}
                    placeholder="Enter Roblox username..."
                    className="w-full bg-[#0d0f14] border border-[#242832] focus:border-[#00a2ff] focus:ring-1 focus:ring-[#00a2ff]/40 rounded-xl py-3 pl-10 pr-4 text-sm text-white placeholder-gray-500 outline-none transition-all"
                  />
                </div>
                <button
                  type="button"
                  disabled={isVerifying || !claimUsername.trim()}
                  onClick={() => verifyUser(claimUsername)}
                  className="bg-[#1b202c] hover:bg-[#232938] border border-[#2d3444] text-gray-200 font-semibold px-4 py-3 rounded-xl transition-all active:scale-95 text-xs flex items-center gap-1.5 cursor-pointer shrink-0 disabled:opacity-50"
                >
                  {isVerifying ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-[#00a2ff]" />
                  ) : (
                    <span>Check Avatar</span>
                  )}
                </button>
              </div>
            </div>

            {/* Select Reward Amount */}
            <div>
              <label className="block text-xs font-semibold text-gray-300 uppercase tracking-wider mb-2">
                Choose Reward Tier
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[500, 1000, 2500, 5000].map((amt) => {
                  const isSelected = selectedAmount === amt;
                  return (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setSelectedAmount(amt)}
                      className={`py-3 px-3 rounded-xl text-center transition-all border cursor-pointer ${
                        isSelected
                          ? 'bg-[#00e676]/15 border-[#00e676] text-[#00e676] shadow-md shadow-[#00e676]/10'
                          : 'bg-[#0d0f14] border-[#242832] text-gray-300 hover:border-gray-500'
                      }`}
                    >
                      <div className="text-xs font-medium text-gray-400">Reward</div>
                      <div className="text-sm font-black font-mono tabular-nums mt-0.5">
                        {amt.toLocaleString()} R$
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Claim Action Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isClaiming || isVerifying || poolRemaining < selectedAmount}
                className="w-full bg-gradient-to-r from-emerald-500 to-[#00e676] hover:from-[#00e676] hover:to-emerald-400 text-[#0c0e12] font-black py-4 rounded-xl shadow-lg shadow-[#00e676]/25 transform active:scale-95 transition-all text-sm uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isClaiming ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-black" />
                    <span>Processing Transfer...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 fill-black text-black" />
                    <span>
                      Claim {selectedAmount.toLocaleString()} R$
                      {verifiedUser ? ` to @${verifiedUser.username}` : ''}
                    </span>
                  </>
                )}
              </button>
            </div>
          </form>

          <div className="mt-4 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-400 gap-2">
            <span className="flex items-center gap-1.5 text-gray-400">
              <ShieldCheck className="w-4 h-4 text-[#00e676]" />
              <span>Anti-bot protected · Synced with Roblox & Rolimon's profiles</span>
            </span>
            <span className="font-mono text-gray-400">
              Instant Credit
            </span>
          </div>
        </div>

      </div>

      {/* Account Confirmation Modal (Before claiming, verifies account with headshot, friends, following & join date) */}
      {verifiedUser && (
        <AccountConfirmModal
          isOpen={isConfirmModalOpen}
          user={verifiedUser}
          claimAmount={selectedAmount}
          onConfirm={handleConfirmClaim}
          onCancel={() => setIsConfirmModalOpen(false)}
          isProcessing={isClaiming}
        />
      )}
    </section>
  );
};
