import React, { useState, useMemo } from 'react';
import { ListFilter, Search, Inbox, ExternalLink, ShieldCheck, TrendingUp } from 'lucide-react';
import { LedgerItem } from '../types';
import { DEFAULT_AVATAR } from '../utils/roblox';

interface LiveLedgerProps {
  ledger: LedgerItem[];
}

export const LiveLedger: React.FC<LiveLedgerProps> = ({ ledger }) => {
  const [activeFilter, setActiveFilter] = useState<'ALL' | '5000' | '2500' | '1000'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredItems = useMemo(() => {
    return ledger.filter((item) => {
      // Amount filter
      if (activeFilter === '5000' && item.amount < 5000) return false;
      if (activeFilter === '2500' && item.amount !== 2500) return false;
      if (activeFilter === '1000' && item.amount !== 1000) return false;

      // Query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesRecipient = item.recipient.toLowerCase().includes(q);
        const matchesNote = item.note.toLowerCase().includes(q);
        return matchesRecipient || matchesNote;
      }
      return true;
    });
  }, [ledger, activeFilter, searchQuery]);

  return (
    <section id="ledger-section" className="bg-[#14161c] border border-[#242832] rounded-3xl p-6 sm:p-8 shadow-xl">
      {/* Header & Filter Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-[#242832]">
        <div>
          <div className="flex items-center gap-2.5">
            <ListFilter className="w-5 h-5 text-[#00e676]" />
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Live Robux Claims Feed
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-gray-400 mt-1">
            Realtime community claim transactions with authentic player avatar headshots
          </p>
        </div>

        {/* Filter buttons & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by player..."
              className="bg-[#0e1015] border border-[#242832] focus:border-[#00e676] rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-gray-500 outline-none w-full sm:w-44 transition-all"
            />
          </div>

          {/* Segmented Filter Control */}
          <div className="flex items-center gap-1 bg-[#0e1015] p-1 rounded-xl border border-[#242832] self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setActiveFilter('ALL')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeFilter === 'ALL'
                  ? 'bg-[#00e676] text-[#0e1015] font-bold shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              All Claims
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('5000')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeFilter === '5000'
                  ? 'bg-[#00e676] text-[#0e1015] font-bold shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              5,000 R$ Tier
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('2500')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeFilter === '2500'
                  ? 'bg-[#00e676] text-[#0e1015] font-bold shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              2,500 R$ Tier
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('1000')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeFilter === '1000'
                  ? 'bg-[#00e676] text-[#0e1015] font-bold shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              1,000 R$ Tier
            </button>
          </div>
        </div>
      </div>

      {/* Table Container */}
      <div className="mt-6 overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[650px]">
          <thead>
            <tr className="text-xs uppercase font-bold text-gray-400 border-b border-[#242832]/80 pb-3">
              <th className="py-3 px-4">Player / Recipient</th>
              <th className="py-3 px-4">Claimed Reward</th>
              <th className="py-3 px-4">Reward Pool Source</th>
              <th className="py-3 px-4">Claim Status</th>
              <th className="py-3 px-4 text-right">Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#242832]/50 text-sm font-medium">
            {filteredItems.map((item) => (
              <tr key={item.id} className="hover:bg-[#181b23] transition-colors">
                <td className="py-3.5 px-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.avatar}
                      alt={item.recipient}
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                      }}
                      className="w-9 h-9 rounded-xl border border-[#2b303d] object-cover bg-[#0d0f14]"
                    />
                    <div>
                      <div className="font-bold text-white text-xs sm:text-sm flex items-center gap-1.5">
                        <span>@{item.recipient}</span>
                        <a
                          href={item.rolimonsUrl || 'https://www.rolimons.com/players'}
                          target="_blank"
                          rel="noreferrer"
                          className="text-cyan-400 hover:text-cyan-200 transition-colors"
                          title="View on Rolimon's Players"
                        >
                          <TrendingUp className="w-2.5 h-2.5" />
                        </a>
                        <a
                          href={`https://www.roblox.com/search/users?keyword=${encodeURIComponent(item.recipient)}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-gray-500 hover:text-gray-300"
                          title="View on Roblox"
                        >
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </div>
                      <div className="text-[11px] text-gray-400 truncate max-w-[200px]">
                        {item.note}
                      </div>
                    </div>
                  </div>
                </td>

                <td className="py-3.5 px-4">
                  <span className="font-mono tabular-nums font-extrabold text-[#00e676] bg-[#00e676]/10 px-2.5 py-1 rounded-md border border-[#00e676]/25 text-xs">
                    +{item.amount.toLocaleString()} R$
                  </span>
                </td>

                <td className="py-3.5 px-4 text-xs text-gray-300">
                  <span className="flex items-center gap-1.5 text-gray-400">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#00a2ff]" />
                    <span>Daily Community Pool</span>
                  </span>
                </td>

                <td className="py-3.5 px-4">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full border bg-[#00e676]/15 text-[#00e676] border-[#00e676]/30">
                    CLAIMED
                  </span>
                </td>

                <td className="py-3.5 px-4 text-right text-xs text-gray-400 font-mono tabular-nums">
                  {item.time}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filteredItems.length === 0 && (
        <div className="py-14 text-center text-gray-400 space-y-2">
          <Inbox className="w-8 h-8 text-gray-600 mx-auto" />
          <p className="text-sm font-medium">No claims found matching this filter.</p>
        </div>
      )}
    </section>
  );
};
