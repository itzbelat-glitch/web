import React from 'react';
import { Coins, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { setSoundEnabled } from '../utils/audio';

interface NavbarProps {
  totalClaimed: number;
  activeClaimers: number;
  onClaimClick: () => void;
  soundState: boolean;
  onToggleSound: (enabled: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  totalClaimed,
  activeClaimers,
  onClaimClick,
  soundState,
  onToggleSound,
}) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSoundToggle = () => {
    const next = !soundState;
    setSoundEnabled(next);
    onToggleSound(next);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#14161c]/90 backdrop-blur-md border-b border-[#242832]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="flex items-center gap-3 cursor-pointer select-none shrink-0"
        >
          <div className="w-11 h-11 bg-gradient-to-tr from-[#00e676] to-[#00a2ff] rounded-xl flex items-center justify-center shadow-lg shadow-[#00e676]/20 transform hover:scale-105 transition-transform duration-200">
            <span className="text-[#0e1015] font-black text-xl tracking-tighter">R$</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-extrabold tracking-tight text-white">BloxGift</span>
              <span className="text-[10px] font-bold text-[#00e676] uppercase tracking-wider">Claims</span>
            </div>
            <p className="text-[11px] text-gray-400 hidden sm:block">Roblox Daily Community Robux Portal</p>
          </div>
        </div>

        {/* Zone 2: Single-line Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-300">
          <button
            onClick={() => scrollTo('daily-pool-section')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Claim Pool
          </button>
          <button
            onClick={() => scrollTo('pulse-section')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Activity Pulse
          </button>
          <button
            onClick={() => scrollTo('ledger-section')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Live Claims
          </button>
          <button
            onClick={() => scrollTo('leaderboard-section')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Top Claimers
          </button>
        </nav>

        {/* Zone 3: Primary Action & Audio Toggle */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Subtle Live Stats */}
          <div className="hidden sm:flex items-center gap-4 text-xs text-gray-400 bg-[#0f1116] border border-[#242832] px-3.5 py-1.5 rounded-lg">
            <div>
              Claimed Today <span className="text-[#00e676] font-bold font-mono tabular-nums ml-1">{totalClaimed.toLocaleString()} R$</span>
            </div>
            <span className="text-gray-600" aria-hidden="true">·</span>
            <div>
              Claimers <span className="text-white font-bold font-mono tabular-nums ml-1">{activeClaimers.toLocaleString()}</span>
            </div>
          </div>

          <button
            onClick={handleSoundToggle}
            className="p-2.5 rounded-xl bg-[#1a1d24] border border-[#242832] text-gray-400 hover:text-white hover:border-gray-500 transition-all cursor-pointer"
            title={soundState ? 'Mute sound effects' : 'Enable sound effects'}
            aria-label="Toggle sound"
          >
            {soundState ? <Volume2 className="w-4 h-4 text-[#00a2ff]" /> : <VolumeX className="w-4 h-4 text-gray-500" />}
          </button>

          <button
            onClick={onClaimClick}
            className="bg-gradient-to-r from-emerald-500 to-[#00e676] hover:from-[#00e676] hover:to-emerald-400 text-[#0c0e12] font-black px-4 py-2.5 rounded-xl shadow-lg shadow-[#00e676]/25 hover:shadow-[#00e676]/40 transform active:scale-95 transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap text-sm"
          >
            <Coins className="w-4 h-4" />
            <span>Claim Robux</span>
          </button>
        </div>
      </div>
    </header>
  );
};
