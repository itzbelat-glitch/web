import React from 'react';
import { Trophy, ExternalLink, CheckCircle2, TrendingUp, Sparkles } from 'lucide-react';
import { LeaderboardUser } from '../types';
import { DEFAULT_AVATAR } from '../utils/roblox';

interface LeaderboardProps {
  topClaimers: LeaderboardUser[];
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ topClaimers }) => {
  return (
    <section id="leaderboard-section" className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Trophy className="w-5 h-5 text-amber-400" />
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Top Daily Claimers
            </h2>
            <p className="text-xs text-gray-400">
              Leading Roblox players with verified 3D character avatars
            </p>
          </div>
        </div>

        <a
          href="https://www.rolimons.com/players"
          target="_blank"
          rel="noreferrer"
          className="text-xs text-cyan-400 hover:underline flex items-center gap-1 font-semibold"
        >
          <span>Rolimon's Player Rankings</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
        {topClaimers.map((user) => {
          const isFirstPlace = user.rank === 1;

          return (
            <div
              key={user.rank}
              className={`relative overflow-hidden bg-[#14161c] border ${user.borderColor} rounded-2xl p-5 flex flex-col justify-between shadow-xl transition-all hover:-translate-y-1 duration-300 ${
                isFirstPlace
                  ? 'bg-gradient-to-b from-amber-500/10 via-[#14161c] to-[#111318] shadow-amber-500/10 border-amber-400/60'
                  : ''
              }`}
            >
              {/* Top Row: Rank Badge & Actions */}
              <div className="flex items-center justify-between z-10">
                <div className="flex items-center gap-2">
                  <span className="text-xl" title={`Rank #${user.rank}`}>
                    {user.badge}
                  </span>
                  <span
                    className={`text-[11px] font-black font-mono uppercase tracking-wider px-2 py-0.5 rounded-md ${
                      isFirstPlace
                        ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                        : 'bg-[#1e2330] text-gray-300'
                    }`}
                  >
                    Rank #{user.rank}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <a
                    href={user.rolimonsUrl || 'https://www.rolimons.com/players'}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-xl bg-[#1e222c] hover:bg-cyan-950/70 text-cyan-300 border border-[#2c3240] transition-colors"
                    title={`View @${user.username} on Rolimon's`}
                  >
                    <TrendingUp className="w-3.5 h-3.5" />
                  </a>

                  <a
                    href={`https://www.roblox.com/search/users?keyword=${encodeURIComponent(user.username)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-xl bg-[#1e222c] hover:bg-[#282d3b] text-gray-300 hover:text-white border border-[#2c3240] transition-colors"
                    title={`View @${user.username} on Roblox`}
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Center: Full Body Avatar Character Pose Render */}
              <div className="my-4 flex justify-center items-center relative py-2">
                <div className="relative w-36 h-48 sm:w-40 sm:h-52 flex items-center justify-center">
                  <div className="absolute inset-0 bg-radial from-[#00a2ff]/10 to-transparent rounded-full blur-xl pointer-events-none" />
                  <img
                    src={user.avatarFull || user.avatar}
                    alt={user.displayName}
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = user.avatar || DEFAULT_AVATAR;
                    }}
                    className="w-full h-full object-contain filter drop-shadow-[0_10px_15px_rgba(0,0,0,0.5)] z-10 transition-transform duration-300 hover:scale-105"
                  />
                </div>
              </div>

              {/* Bottom: Player Handle, Display Name, and Claimed Amount */}
              <div className="pt-3 border-t border-[#232733] z-10">
                <div className="flex items-center justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-extrabold text-white text-base truncate">
                        {user.displayName}
                      </h3>
                      <CheckCircle2 className="w-4 h-4 text-[#00e676] shrink-0" />
                    </div>
                    <div className="text-xs font-semibold text-[#00a2ff] truncate">
                      @{user.username}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-[10px] text-gray-400 font-medium uppercase">
                      Total Claimed
                    </div>
                    <div className="text-sm font-black text-[#00e676] font-mono tabular-nums">
                      +{user.amountGifted.toLocaleString()} R$
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
