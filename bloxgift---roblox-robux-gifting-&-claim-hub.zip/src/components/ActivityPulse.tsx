import React, { useEffect, useState } from 'react';
import { Activity, Users, Coins, TrendingUp, Clock, Sparkles } from 'lucide-react';

interface ActivityPulseProps {
  hourlyActiveUsers: number;
  hourlyRobuxClaimed: number;
  lastClaimAmount?: number;
  onQuickClaimClick?: () => void;
}

export const ActivityPulse: React.FC<ActivityPulseProps> = ({
  hourlyActiveUsers,
  hourlyRobuxClaimed,
  lastClaimAmount,
  onQuickClaimClick,
}) => {
  const [pulseHighlight, setPulseHighlight] = useState(false);
  const [currentTimeWindow, setCurrentTimeWindow] = useState('');

  // Update current hour label
  useEffect(() => {
    const updateWindow = () => {
      const now = new Date();
      const currentHour = now.getHours();
      const startHour = (currentHour % 12) || 12;
      const startAmPm = currentHour >= 12 ? 'PM' : 'AM';
      const nextHour = ((currentHour + 1) % 12) || 12;
      const nextAmPm = (currentHour + 1) >= 12 && (currentHour + 1) < 24 ? 'PM' : 'AM';
      setCurrentTimeWindow(`${startHour}:00 ${startAmPm} – ${nextHour}:00 ${nextAmPm}`);
    };
    updateWindow();
    const interval = setInterval(updateWindow, 60000);
    return () => clearInterval(interval);
  }, []);

  // Flash subtle pulse ring when claim amount updates
  useEffect(() => {
    if (hourlyRobuxClaimed) {
      setPulseHighlight(true);
      const timer = setTimeout(() => setPulseHighlight(false), 1200);
      return () => clearTimeout(timer);
    }
  }, [hourlyRobuxClaimed]);

  return (
    <div id="pulse-section" className="relative overflow-hidden bg-gradient-to-r from-[#12141a] via-[#161922] to-[#13161e] border border-[#262b37] rounded-2xl p-4 sm:p-5 shadow-lg transition-all duration-300">
      {/* Subtle background glow */}
      <div className="absolute top-0 right-1/4 w-60 h-20 bg-[#00e676]/10 rounded-full blur-2xl pointer-events-none" />

      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
        
        {/* Left: Badge, Title & Hour Context */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className={`w-10 h-10 rounded-xl bg-[#00e676]/10 border border-[#00e676]/30 flex items-center justify-center text-[#00e676] transition-transform duration-300 ${pulseHighlight ? 'scale-110 shadow-md shadow-[#00e676]/20' : ''}`}>
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
            {/* Live active beacon */}
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00e676] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#00e676]"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-bold text-white tracking-tight">
                Activity Pulse
              </h3>
              <span className="text-[10px] font-mono font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/25 px-2 py-0.5 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                LIVE METRICS
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-400 mt-0.5">
              <Clock className="w-3 h-3 text-gray-500" />
              <span>Current Hour</span>
              <span className="text-gray-600" aria-hidden="true">·</span>
              <span className="font-mono text-gray-300 text-[11px]">{currentTimeWindow || 'Past 60 Minutes'}</span>
            </div>
          </div>
        </div>

        {/* Center / Right: Dynamic Metrics Counters */}
        <div className="flex flex-wrap items-center gap-3 sm:gap-6 w-full md:w-auto justify-between md:justify-end">
          
          {/* Active Users in Current Hour */}
          <div className="flex items-center gap-3 bg-[#0d0f14] border border-[#242832] px-4 py-2.5 rounded-xl flex-1 sm:flex-initial">
            <div className="p-2 rounded-lg bg-[#00a2ff]/10 text-[#00a2ff]">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] text-gray-400 font-medium leading-none mb-1">
                Active Users (1h)
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-base sm:text-lg font-extrabold text-white font-mono tabular-nums tracking-tight">
                  {hourlyActiveUsers.toLocaleString()}
                </span>
                <span className="text-[10px] font-semibold text-emerald-400 flex items-center">
                  <TrendingUp className="w-2.5 h-2.5 mr-0.5" />
                  +14%
                </span>
              </div>
            </div>
          </div>

          {/* Total Robux Claimed in Current Hour */}
          <div className={`flex items-center gap-3 bg-[#0d0f14] border transition-all duration-300 px-4 py-2.5 rounded-xl flex-1 sm:flex-initial ${
            pulseHighlight ? 'border-[#00e676] shadow-lg shadow-[#00e676]/20 bg-[#0d1612]' : 'border-[#242832]'
          }`}>
            <div className="p-2 rounded-lg bg-[#00e676]/10 text-[#00e676]">
              <Coins className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] text-gray-400 font-medium leading-none mb-1">
                Robux Claimed (1h)
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-base sm:text-lg font-black text-[#00e676] font-mono tabular-nums tracking-tight">
                  {hourlyRobuxClaimed.toLocaleString()} R$
                </span>
                {lastClaimAmount ? (
                  <span className="text-[10px] font-mono text-gray-400 hidden sm:inline">
                    (+{lastClaimAmount} claimed)
                  </span>
                ) : null}
              </div>
            </div>
          </div>

          {/* Quick Claim Shortcut */}
          {onQuickClaimClick && (
            <button
              onClick={onQuickClaimClick}
              className="hidden lg:flex items-center gap-1.5 text-xs font-bold text-gray-300 hover:text-white bg-[#1a1e28] hover:bg-[#222735] border border-[#2b3140] px-3 py-2.5 rounded-xl transition-all active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Claim Now</span>
            </button>
          )}

        </div>

      </div>
    </div>
  );
};
